/*
Navicat MySQL Data Transfer

Source Server         : 本地数据库
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : goods

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2019-01-19 18:30:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for commodity_categories
-- ----------------------------
DROP TABLE IF EXISTS `commodity_categories`;
CREATE TABLE `commodity_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` char(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '类别名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of commodity_categories
-- ----------------------------
INSERT INTO `commodity_categories` VALUES ('1', '坚果');
INSERT INTO `commodity_categories` VALUES ('2', '干果');
INSERT INTO `commodity_categories` VALUES ('3', '饮品');

-- ----------------------------
-- Table structure for commodity_information
-- ----------------------------
DROP TABLE IF EXISTS `commodity_information`;
CREATE TABLE `commodity_information` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `number` char(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品编号',
  `category_id` int(11) DEFAULT NULL COMMENT '商品类别id，关联commodity_categories表',
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '商品名称',
  `price` double DEFAULT NULL COMMENT '商品价格',
  `phone` char(12) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '厂家电话',
  `email` char(30) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '厂家邮箱',
  `photo_url` char(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '商品图片地址',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of commodity_information
-- ----------------------------
INSERT INTO `commodity_information` VALUES ('12', '003', '3', '红牛', '5', '', '', 'hongniu.jpg');
INSERT INTO `commodity_information` VALUES ('6', '002', '1', '坚果', '21', '', null, 'biantaoren.jpg');
INSERT INTO `commodity_information` VALUES ('7', '002', '1', '坚果', '21', '', null, 'hetao.jpg');
INSERT INTO `commodity_information` VALUES ('8', '002', '1', '坚果', '21', '', null, 'hetao.jpg');
INSERT INTO `commodity_information` VALUES ('9', '002', '2', '干果', '21', '', null, 'hetao.jpg');
INSERT INTO `commodity_information` VALUES ('11', '001', '3', '可口可乐', '4', '', null, 'coco.jpg');
INSERT INTO `commodity_information` VALUES ('13', '006', '3', '冰红茶', '3.5', '18855098934', '1571599294@qq.com', 'iceTea.jpg');

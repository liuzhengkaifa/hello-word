<?php
namespace app\api\controller;
use think\Validate;
use phpmailer\PHPMailer;

class Code extends Common{
  /**
   * 接收过滤后的用户名和是否应存在数据库
   * @return [type] [description]
   */
     public function get_code(){
          $data = $this->params;
          $username = $data['username'];
          $exist = $data['is_exist'];
          //检查用户名，比较是邮箱还是手机号
          $username_type = $this->check_username($username);
          switch($username_type){
               case 'phone':
               $this->get_code_by_username($username,'phone',$exist);
               break;
               case 'email':
               $this->get_code_by_username($username,'email',$exist);
               break;
          }
     }
     /**
      * 检验输入的用户名属于手机号还是邮箱
      * @param  [type] $username [description]
      * @return [type]           [description]
      */
     public function check_username($username){
          //判断是否为邮箱
          $is_email = Validate::is($username,'email')?1:0;
          //判断是否为手机
          $is_phone = preg_match('/^1[34578]\d{9}$/',$username)?4:2;
          //最终结果
          $flag = $is_email+$is_phone;
          //手机->4  邮箱->3  既不是手机也不是邮箱->2
          switch($flag){
               case 2:
                    $this->return_msg(400,'邮箱或手机号不正确');
                    break;
               case 3:
                    return 'email';
                    break;
               case 4:
                    return 'phone';
                    break;
          }
     }
     /**
      * 将时间和验证码存入session，调用方法发送验证码
      * @param  [type] $username [description]
      * @param  [type] $type     [description]
      * @param  [type] $exist    [description]
      * @return [type]           [description]
      */
     public function get_code_by_username($username,$type,$exist){
          if($type=='phone'){
               $type_name = '手机';
          }else{
               $type_name = '邮箱';
          }
          //检测手机号/邮箱是否存在
          $this->check_exist($username,$type,$exist);
         // 检查验证码请求频率，30s一次
          if(session("?".$username.'_last_send_time')){
               if(time()-session($username.'_last_send_time')<30){
                    $this->return_msg(400,$type_name.'验证码每30s只能发送一次，请稍后重试');
               }
          }
          //生成一个6位验证码
          $code = $this->make_code(6);
          //使用session存储验证码，方便比对，md5加密
          $md5_code = md5($username.'_'.md5($code));
          session($username.'_code',$md5_code);
          //使用session存储验证码的发送时间
          session($username.'_last_send_time',time());
          //发送验证码
          if($type=='phone'){
               $this->send_code_to_phone($username,$code);
          }else{
               $this->send_code_to_email($username,$code);
          }
     }
     //
     /**
      * 检查邮箱或手机号是否存在
      * @param  [string] $value [手机号或邮箱]
      * @param  [string] $type  [手机号或邮箱类别]
      * @param  [exist] $exist [手机号或邮箱是否已存在，0:应当不存在，1：应当存在]
      * @return [type]        [description]
      */
     public function check_exist($value,$type,$exist){
           $type_num = $type == 'phone'?2:4;
           $flag = $type_num+$exist;
           $phone_res = db('api_user')->where('user_phone',$value)->find();
           $email_res = db('api_user')->where('user_email',$value)->find();
           switch($flag){
               //2+0 user_phone已被占用
               case 2:
               if($phone_res){
                    $this->return_msg(400,'此手机号已被占用！');
               }
               break;
               //2+1 user_phone 不存在
               if(!$phone_res){
                    $this->return_msg(400,'此手机号不存在！');
               }
               break;
               // 4+0 user_email 已被占用
               case 4:
               if($email_res){
                    $this->return_msg(400,'此邮箱已被占用！');
               }
               break;
               //4+1 user_email 不存在
               case 5:
               if(!$email_res){
                    $this->return_msg(400,'此邮箱不存在！');
               }
               break;
           }
     }
     /**
      * 生成一个6位验证码
      * @param  [type] $num [description]
      * @return [type]      [description]
      */
     public function make_code($num){
          $max = pow(10,$num)-1;
          $min = pow(10,$num-1);
          return rand($min,$max);
     }
     /**
      * 发送验证码到邮箱
      * @param  [type] $email [description]
      * @param  [type] $code  [description]
      * @return [type]        [description]
      */
     public function send_code_to_email($email, $code){
         $toemail = $email;
         $mail    = new PHPMailer();
         $mail->isSMTP();
         $mail->CharSet    = 'utf8'; // 设置字符集

         //使用网易163邮箱发邮箱
         $mail->Host       = 'smtp.163.com'; // smtp服务器
         $mail->SMTPAuth   = true;
         $mail->Username   = "m18855098934@163.com";
         $mail->Password   = "liuzhengno1111";    //授权码
         $mail->SMTPSecure = 'ssl';
         $mail->Port       = 994;
         $mail->setFrom('m18855098934@163.com', 'lz接口测试');//设置发件人邮箱地址 这里填入上述提到的“发件人邮箱”
         $mail->addAddress($toemail, 'test');     //设置收件人邮箱地址
         $mail->addReplyTo('m18855098934@163.com', 'lz接口测试'); //用户回复邮箱地址，用户名
         $mail->Subject = "您有新的验证码!"; // 邮件标题
          $mail->Subject = "验证码信息!"; // 邮件标题
         $mail->Body    = "这是一个测试邮件,您的验证码是$code,验证码的有效期为1分钟,本邮件请勿回复!"; // 邮件内容
         // for($i=0;$i<10;$i++){
         //       $mail->send();
         //       echo "$i";
         // }

    if (!$mail->send()) {
        $this->return_msg(400, $mail->ErrorInfo);
    } else {
        $this->return_msg(200, '验证码已经发送成功,请注意查收!');
    }
}
     public function send_code_to_phone($phone,$code){
          $this->return_msg(400,'暂不支持手机号验证！');
     }

}
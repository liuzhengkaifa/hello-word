<?php
namespace app\api\controller;
use think\Controller;
use think\Request;
use think\Validate;
class Common extends Controller{
     protected $request;//用来处理参数
     protected $validate;//用来验证数据/参数
     protected $params;//过滤后符合要求的参数
     protected $rules = array(
               'User'=>array(
                    'login'=>array(
                         'user_name'=>['require','max'=>20],//有正则用数组
                         'user_pwd'=>'require'
                         ),
                    'register'=>array(
                          'user_name'=>'require',
                          'user_pwd'=>'require',
                          'code'=>'require|number|length:6',
                      ),
                    'upload_head_img'=>array(
                          'user_id'=>'require|number',
                          'user_icon'=>'require|image|fileSize:2000000|fileExt:jpg,png,bmp,jpeg',
                      ),
                    'change_pwd'=>array(
                          'user_name'=>'require',
                          // 'user_code'=>'require|number|length:6',
                          'user_ini_pwd'=>'require|number',
                          'user_pwd'=>'require|number',
                      ),
                    'find_pwd'=>array(
                          'user_name'=>'require',
                          'code'=>'require|number|length:6',
                          'user_pwd'=>'require',
                      ),
                    'bind_email'=>array(
                          'user_name'=>'require',
                          'user_email'=>'require|email',
                          'code'=>'require|number|length:6',
                      ),
                    'set_nickname'=>array(
                          'user_name'=>'require',
                          'user_pwd'=>'require',
                          'user_nickname'=>'require|chsDash',
                      ),
                    ),
               'Article'=>array(
                  'add_article'=>array(
                        'article_uid' => 'require|number',
                        'article_title'=>'require|chsDash'
                    ),
                  'article_list'=>array(
                        'user_id'=>'require|number',
                        'num'=>'number',
                        'page'=>'number',
                    ),
                  'article_detail'=>array(
                        'article_id' => 'require|number',
                    ),
                  'article_update'=>array(
                        'article_id' => 'require|number',
                        'article_title'=>'chsDash'
                    ),
                  'article_delete'=>array(
                        'article_id'=>'require|number'
                    ),
              ),
                'Code'=>array(
                    'get_code'=>array(
                        'username'=>'require',
                        'is_exist'=>'require|number|length:1',
                      ),
                    ),

              //    'Article'=>array(
              //     'article_detail'=>array(
              //           'article_id' => 'require|number',
              //       ),
              // ),
              //     'Article'=>array(

              // ),

          );
     protected function _initialize(){
          parent::_initialize();
          $this->request = Request::instance();
          // $this->checkTime($this->request->only(['time']));
          // $this->checkToken($this->request->param());
          // $this->params=$this->checkParams($this->request->except(['time','token']));
            $this->params=$this->checkParams($this->request->param(true));
     }
     /**
      * 验证请求是否超时
      * @param  [array] $arr [包含时间戳的参数数组]
      * @return [json]      [检测结果]
      */
     public function checkTime($arr){
          //intval()纯字符串返回0   如果123hello截取前面的返回123 空数组返回0  有值数组返回1
          if(!isset($arr['time'])||intval($arr['time'])<=1){
               $this->return_msg(400,"时间戳不正确！");
          }
          if(time()-intval($arr['time'])>60){
               $this->return_msg(400,'请求超时！');
          }
     }
     /**
      * api 数据返回
      * @param  [int] $code [结果码 200：正常/4**数据问题/5**服务器问题]
      * @param  string $msg  [接口要返回的提示信息]
      * @param  array  $data [接口要返回的数据]
      * @return [json]       [最终的json数据]
      */
     public function return_msg($code,$msg='',$data=[]){
          // 组合数据
          $return_data['code']=$code;
          $return_data['msg']=$msg;
          $return_data['data']=$data;
          //返回信息并终止脚本
          echo json_encode($return_data);die;
     }
     /**
      * 验证token
      * @param  [type] $arr [description]
      * @return [type]      [description]
      */
     public function checkToken($arr){
          //api传过来的token
          if(!isset($arr['token'])||empty($arr['token'])){
            $this ->return_msg(400,'token不能为空');
          }
          $app_token = $arr['token'];//api传过来的token
          //服务器端生成token
          unset($arr['token']);//将token从数组中去除
          $service_token='';
          foreach($arr as $key => $value){
              $service_token = md5($value);
          }
          $service_token = md5('api_'.$service_token.'_api');//服务器端即时生成的token
          // dump($service_token);die();
          //对比token,返回结果
          if($app_token!==$service_token){
               $this->return_msg(400,'token值不正确！');
          }
     }
     /**
      * 验证参数，返回数据
      * @param  [array] $arr [除time和token外的所有参数]
      * @return [type]      [正确的参数数组]
      */
     public function checkParams($arr){
          //获取验证规则
          $rule = $this->rules[$this->request->controller()][$this->request->action()];     //验证规则的第一个键值为控制器名，第二个键值为方法
          //验证参数并返回错
          $this->validate = new Validate($rule);  //实例化validate类
          if(!$this->validate->check($arr)){
               $this->return_msg(400,$this->validate->getError());
          }
              return $arr;
     }
}
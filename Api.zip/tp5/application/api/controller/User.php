<?php
namespace app\api\controller;

use app\api\controller\Code;

class User extends Common{
     /**
      * 用户登录
      * @return [type] [description]
      */
     public function login(){
          $code = new code();
          //接收参数
          $data = $this->params;
          //检测用户名
          $user_name_type=$code->check_username($data['user_name']);
          switch($user_name_type){
               case 'phone':
               $code->check_exist($data['user_name'],'phone',1);
               $db_res = db('api_usr')->field('user_id,user_nickname,user_phone,user_email,user_rtime,user_pwd')->where('user_phone',$data['user_name'])->find();
               break;
               case 'email':
               $code->check_exist($data['user_name'],'email',1);
               $db_res = db('api_user')->field('user_id,user_nickname,user_phone,user_email,user_rtime,user_pwd')->where('user_email',$data['user_name'])->find();
               break;
          }
          if($db_res['user_pwd']!=$data['user_pwd']){
               $this->return_msg(400,'用户名或者密码不正确！');
          }else{
               unset($db_res['user_pwd']);
               $this->return_msg(200,'登陆成功',$db_res);
          }

     }
     /**
      * 用户注册
      * @return [type] [description]
      */
     public function register(){
          $code = new Code();
          //接收参数
          $data = $this->params;
          //校验验证码
          $this->check_code($data['user_name'],$data['code']);
          //检测用户
         $user_name_type = $code->check_username($data['user_name']);
          switch($user_name_type){
               case 'phone':
               $code->check_exist($data['user_name'],'phone',0);
               $data['user_phone']=$data['user__name'];
               break;
               case 'email':
               $code->check_exist($data['user_name'],'phone',0);
               $data['user_email']=$data['user_name'];
               break;
          }
          //将用户信息写入数据库
          unset($data['user_name']);
          $data['time']=time();
          $res = db('api_user')->insert($data);
          if(!$res){
               $this->return_msg(400,'用户注册失败');
          }else{
               $this->return_msg(200,'用户注册成功');
          }

     }
     /**
      * 校验验证码是否在规定时间内输入正确
      * @param  [type] $username [手机号或者邮箱账号]
      * @param  [type] $code     [6位数字验证码]
      * @return [type]           [验证信息]
      */
     public function check_code($username,$code){
          $last_time = session($username.'_last_send_time');
          if(time()-$last_time>60){
               dump($username);
               dump(time());
               dump($last_time);
               dump(time()-$last_time);
               $this->return_msg(400,'校验超时，请在一分钟内验证');
          }
          //检测是否正确
          $md5_code=md5($username.'_'.md5($code));
          dump($md5_code);
          dump(session($username."_code"));
          if(session($username."_code")!==$md5_code){
               $this->return_msg(400,'验证码不正确！');
          }
          //不论正确与否，每个验证码只验证一次
          session($username."_code",null);
     }
     /**
      * 上传头像
      * @return [type] [description]
      */
     public function upload_head_img(){
         //接收参数
         $data = $this->params;
         //上传文件，获得路径
         $head_img_path = $this->upload_file($data['user_icon'],'head_img');
         //存入数据库
         $res = db('api_user')->where('user_id',$data['user_id'])->setField('user_icon',$head_img_path);
         if($res){
          $this->return_msg(200,'头像上传成功！',$head_img_path);
         }else{
          $this->return_msg(400,'头像上传失败！');
         }
         //
     }
     public function upload_file($file,$tpe=''){
          $info = $file->move(ROOT_PATH.'public'.DS.'uploads');
          if($info){
               $path = 'uploads/'.$info->getSaveName();
               //裁剪图片
               if(!empty($type)){
                    $this->image_edit($path,$type);
               }
               return str_replace('\\','',$path);
          }else{
               $this->return_msg(400,$file->getError());
          }
     }
     public function image_edit($path,$type){
            $image = Image::open(ROOT_PATH . 'public' . $path);
    switch ($type) {
    case 'head_img':
        $image->thumb(200, 200, Image::THUMB_CENTER)->save(ROOT_PATH . 'public' . $path);
        break;
          }
     }
     /**
      * 修改密码
      * @return [type] [description]
      */
     public function change_pwd(){
          //接收参数
          $data = $this->params;
          $user_name = $data['user_name'];
          $code = new Code();
          //校验用户属于email或者phone数据库查找用户账号
          $user_name_type = $code->check_username($user_name);
          switch($user_name_type){
               case 'email':
               $code->check_exist($user_name,'email',1);
               $where['user_email']=$user_name;
               break;
               case 'phone':
               $code->check_exist($user_name,'phone',1);
               $where['user_phone']=$user_name;
               break;
          }
          //修改密码存入数据库
          $db_ini_pwd = db('api_user')->where($where)->value('user_pwd');
          if($db_ini_pwd!==$data['user_ini_pwd']){
               $this->return_msg(400,'原密码错误！');
          }else{
               $res = db('api_user')->where($where)->setField('user_pwd',$data['user_pwd']);
               if($res){
                    $this->return_msg(200,'修改密码成功！');
               }else{
                    $this->return_msg(400,'修改密码失败！');
               }
          }
     }
     /**
      * 找回密码
      * @return [type] [description]
      */
     public function find_pwd(){
          //获取参数
          $data=$this->params;
          $code = new Code();
          //校验验证码
          $this->check_code($data['user_name'],$data['code']);
          //检测用户名
          $user_name_type=$code->check_username($data['user_name']);
          switch($user_name_type){
               case 'email':
                    $code->check_exist($data['user_name'],'email',1);
                    $where['user_email']=$data['user_name'];
                    break;
               case 'phone':
                    $code->check_exist($data['user_name'],'phone',1);
                    $where['user_phone']=$data['user_name'];
                    break;
          }
          $res = db('api_user')->where($where)->setField('user_pwd',$data['user_pwd']);
          if($res){
               $this->return_msg(200,'密码修改成功！');
          }else{
               $this->return_msg(400,'密码修改失败！');
          }
     }
     /**
      * 绑定邮箱
      * @return [type] [description]
      */
     public function bind_email(){
         //获取数据
         $data=$this->params;
         $code=new Code();
         //校验验证码
         $this->check_code($data['user_name'],$data['code']);
         //校验用户是否存在
         $code->check_exist($data['user_name'],'email',1);
         //将修改信息存入数据库
         $res = db('api_user')->where('user_email',$data['user_name'])->setField('user_email',$data['user_email']);
         if($res){
               $this->return_msg(200,'邮箱绑定成功！');
         }else{
               $this->return_msg(400,'邮箱绑定失败！');
         }
     }
     public function set_nickname(){
          //接收参数
          $data = $this->params;
          $code = new Code();
          //校验用户是否存在
          $code->check_exist($data['user_name'],'email',1);
          $db_ini_pwd=db('api_user')->where('user_email',$data['user_name'])->value('user_pwd');
          if($db_ini_pwd!==$data['user_pwd']){
               $this->return_msg(400,'密码错误，请确认后重试');
          }
          else{
          $res = db('api_user')->where('user_email',$data['user_name'])->setField('user_nickname',$data['user_nickname']);
               if($res){
                    $this->return_msg(200,'昵称修改成功！');
               }else{
                    $this->return_msg(400,'昵称修改失败');
               }

          }
     }
}
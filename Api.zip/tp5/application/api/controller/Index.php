<?php
namespace app\api\controller;
/**
 * @Author: anchen
 * @Date:   2018-12-22 19:02:31
 * @Last Modified by:   anchen
 * @Last Modified time: 2018-12-22 19:38:57
 */
class Index{
     public function index($id){
          echo "api/index/index";
          echo "<br>";
          echo $id;
     }
}
<?php
namespace app\api\controller;
class Article extends Common{
     public function add_article(){
          $data = $this->params;
          $data['article_ctime'] = time();
          //参数已过滤直接写入数据库
          $res = db('api_article')->insertGetId($data);
          if($res){
               $this->return_msg(200,'新增文章成功！'.$res);
          }else{
               $this-return_msg(400,'新增文章失败！');
          }
     }
     public function article_list(){
           //接收参数
          $data = $this->params;
           //查询数据库
          $where['article_uid'] = $data['user_id'];
          $where['article_isdel'] = 0;
          $count = db('api_article')->where($where)->count();
          $field = "article_uid,article_ctime,article_title,user_nickname";
          $join = [['api_user u','u.user_id=a.article_uid']];

          if(!isset($data['num'])||!isset($data['page'])){
                $res = db('api_article')->alias('a')->field($field)->join($join)->where($where)->select();//一页查询

          }else{
                $page_num = ceil($count/$data['num']);      //向上取整
                $res = db('api_article')->alias('a')->field($field)->join($join)->where($where)->page($data['page'],$data['num'])->select();//分页查询
          }
         // dump($res);die;
         if($res===false){
          $this->return_msg(400,'查看失败!');
         }else if(empty($res)){
          $this->return_msg(200,'暂无数据!');
         }else{
          // $return_data['page_num']=$page_num;
          $return_data['count']=$count;
          $return_data['articles']=$res;
          $this->return_msg(200,'查询成功！',$return_data);
         }
     }
     public function article_detail(){
          //接收参数
         $data = $this->params;
         $field = 'article_id,article_title,article_ctime,article_content,user_nickname';
         $where['article_id'] = $data['article_id'];
         $join = [['api_user u','u.user_id=a.article_uid']];
         $res = db('api_article')->alias('a')->join($join)->field($field)->where($where)->find();   //链式操作联表查询
          if(!$res){
               $this->return_msg(400,"查询失败！");
          }
          else if(empty($res)){
               $this->return_msg(200,"无数据！");
          }
          else{
               $this->return_msg(200,"查询成功！",$res);
          }
     }
     public function article_update(){
          $data = $this->params;
          $res = db('api_article')->where('article_id',$data['article_id'])->update($data);
          if($res!==false){
               $this->return_msg(200,'修改文章成功！');
          }
          else{
               $this->return_msg(400,'修改文章失败！');
          }
     }
     /**
      * 删除指定文章
      * @return [return] [文章提示信息]
      */
     public function article_delete(){
         $data = $this->params;
         // $res=db('api_article')->where('article_id',$data['article_id'])->delete();
         // $res=db('api_article')->delete($data['article_id']);
         $res = db('api_article')->where('article_id',$data['article_id'])->setField('article_isdel',1);
         dump($res);
         if($res){
          $this->return_msg(200,'文章删除成功');
         }
         elseif (empty($res)) {
          $this->return_msg(400,'该文章不存在');
         }
         else{
          $this->return_msg(400,'文章删除失败');
         }
     }
}
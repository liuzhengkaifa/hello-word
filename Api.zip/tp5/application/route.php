<?php
use think\Route;
// 注册路由到index模块的News控制器的read操作

//api.tp5.com  ===> www.tp5.com/index.php/api
Route::domain('api','api');
/*//api.tp5.com/user/2 ===> www.tp5.com/index.php/api/user/index/id/2
Route::rule('user/:id','user/index');*/
//用户登陆
Route::post('user/login','user/login');
//用户注册
Route::post('user/register','user/register');
//用户登陆
Route::post('user/login','user/login');

//获取验证码
Route::get('code','code/get_code');
//用户上传头像
Route::post('user/icon','user/upload_head_img');
//用户修改密码
Route::post('user/change_pwd','user/change_pwd');
//找回密码
Route::post('user/find_pwd','user/find_pwd');
//用户绑定手机
Route::post('user/bind_email','user/bind_email');
//用户修改昵称
Route::post('user/nickname','user/set_nickname');


//新增文章
Route::post('article','article/add_article');
//查询文章列表
Route::get('articles','article/article_list');
//查询单个文章信息
Route::get('article','article/article_detail');
//修改文章
Route::put('article','article/article_update');
//删除文章
Route::delete('article','article/article_delete');


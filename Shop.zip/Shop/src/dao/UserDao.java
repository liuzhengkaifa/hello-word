package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import vo.UserVo;
public class UserDao {
	private Connection conn=null;
	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public HashMap<Integer,UserVo> getAllUsers() throws Exception{
		 HashMap<Integer,UserVo> hm_user=new HashMap<Integer,UserVo>();
			this.initConnection();
			Statement stat= conn.createStatement();
			String sql="select * from s_user";
			ResultSet rs =  stat.executeQuery(sql);
			while(rs.next()) {
				UserVo user = new UserVo();
				user.setNickName(rs.getString("user_nickName"));
				user.setPassword(rs.getString("user_password"));
				user.setPhone(rs.getString("user_phone"));
				hm_user.put(rs.getInt("user_id"), user);
			}
			this.closeConnection();
			return hm_user;
	}
	
	/**
	 * 注册添加用户或者商家
	 * @author liuzheng   2018/12/18
	 * @param nickName
	 * @param phone
	 * @param password
	 * @throws Exception
	 */
	public void addUser(String nickName,String phone,String password) throws Exception {
		this.initConnection();
		String sql="insert into s_user('user_nickName','user_phone','user_password') values (?,?,?)";
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setString(1, nickName);
		ps.setString(2, phone);
		ps.setString(3,password);
		if(ps.execute()) {
			System.out.println("用户注册成功");
		}else {
			System.out.println("用户注册失败");
		}
	}
	//连接数据库
		public void initConnection()throws Exception {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://116.255.150.51:3306/lroot","lroot_f","liuzheng");
		}
		public void closeConnection()throws Exception{
			conn.close();
		}
}

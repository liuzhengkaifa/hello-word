package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import vo.CommodityVo;

public class CommodityDao {
	private Connection conn = null;

	/**
	 * 获取所有商品信息
	 * @return
	 * @throws Exception
	 */
	public HashMap<Integer, CommodityVo> getAllCommodity() throws Exception {
		HashMap<Integer, CommodityVo> hm_cdy = new HashMap<Integer, CommodityVo>();
		this.initConnection();
		Statement stat = conn.createStatement();
		String sql = "select * from s_commodity";
		ResultSet rs = stat.executeQuery(sql);
		while (rs.next()) {
			CommodityVo cdy = new CommodityVo();
			cdy.setCdyName(rs.getString("cdy_name"));
			cdy.setCdyPrice(rs.getDouble("cdy_price"));
			cdy.setCdyColor(rs.getString("cdy_color"));
			cdy.setCdySize(rs.getString("cdy_size"));
			cdy.setCdyNo(rs.getInt("cdy_no"));
			hm_cdy.put(rs.getInt("cdy_no"), cdy);
			System.out.println("从数据库取到的值"+rs.getString("cdy_name")+rs.getDouble("cdy_price")+rs.getString("cdy_color"));
		}
		this.closeConnection();
		return hm_cdy;
	}

	/**
	 * 添加、修改 商品信息
	 * 
	 * @param cdyName
	 * @param cdyColor
	 * @param cdySize
	 * @param cdyPrice
	 * @param sto_no
	 * @throws Exception
	 */
	public void addCommodity(String cdyName, String cdyColor, String cdySize, double cdyPrice, String sto_no)
			throws Exception {
		String sql = "insert into s_commodity('cdy_name','cdy_color','cdy_size','cdy_size','sto_no') values (?,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, cdyName);
		ps.setString(2, cdyColor);
		ps.setString(3, cdySize);
		ps.setDouble(4, cdyPrice);
		ps.setString(5, sto_no);
		if (ps.execute()) {
			System.out.println("商品添加成功");
		} else {
			System.out.println("商品添加失败");
		}
	}

	/**
	 * 初始化连接数据库
	 * @throws Exception
	 */
	public void initConnection() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection("jdbc:mysql://116.255.150.51:3306/lroot", "lroot_f", "liuzheng");
	}

	/**
	 * 关闭连接释放资源
	 * @throws Exception
	 */
	public void closeConnection() throws Exception {
		conn.close();
	}
}

package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import vo.AddressVo;

public class AddressDao {
	private Connection conn = null;
	/**
	 * @author liuzheng
	 * 获取所有收货地址
	 * @return HashMap<Integer, AddressVo>
	 * @throws Exception
	 */
	public HashMap<Integer, AddressVo> getAllAddress() throws Exception {
		HashMap<Integer, AddressVo> hm_ars = new HashMap<Integer, AddressVo>();
		this.initConnection();
		Statement stat = conn.createStatement();
		String sql = "select * from s_address";
		ResultSet rs = stat.executeQuery(sql);
		while (rs.next()) {
			AddressVo ars = new AddressVo();
			ars.setName(rs.getString("ars_name"));
			ars.setCode(rs.getString("ars_post_code"));
			ars.setAddress(rs.getString("ars_address"));
			ars.setPhone(rs.getString("ars_phone"));
			ars.setArs_no(rs.getInt("ars_no"));
			ars.setUser_id(rs.getInt("user_id"));
			hm_ars.put(rs.getInt("ars_no"), ars);
		}
		this.closeConnection();
		return hm_ars;
	}
	/**
	 * @author liuzheng	
	 * 添加/修改 收货地址
	 * @param name
	 * @param phone
	 * @param code
	 * @param address
	 * @param uid
	 * @throws Exception
	 */
	public void addAddress(String name, String phone,  int code, String address, int uid,int flag,int ars_no) throws Exception {
		this.initConnection();
//		System.out.println("AddressDao的添加地址方法"+name+phone+code+address+uid);
		String sql = null;
		if(flag==1) {
			System.out.println("地址新增语句");
			 sql="insert into s_address(ars_name,ars_phone,ars_post_code,ars_address,user_id) values(?,?,?,?,?)";
		}else if(flag==0) {
			System.out.println("地址修改语句");
			sql="update s_address set ars_name=?,ars_phone=?,ars_post_code=?,ars_address=?,user_id=? where ars_no="+ars_no;
		}
		
		
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, name);
		ps.setString(2, phone);
		ps.setInt(3, code);
		ps.setString(4, address);
		ps.setInt(5, uid);
		if (ps.executeUpdate()==1){
			System.out.println("地址添加成功");
		} else {
			System.out.println("地址添加失败");
		}
		this.closeConnection();
	}
	
	/**
	 * 删除指定收货地址
	 * @param arsNo
	 * @throws Exception
	 */
	public void deleteAddress(int arsNo) throws Exception {
		this.initConnection();
		String sql = "delete from s_address where ars_no = ?";
		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setInt(1, arsNo);
		if (ps.executeUpdate()==1) {
			System.out.println("地址删除成功");
		} else {
			System.out.println("地址删除失败");
		}
		this.closeConnection();

	}

	/**
	 * 初始化连接驱动
	 * @throws Exception
	 */
	public void initConnection() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection("jdbc:mysql://116.255.150.51:3306/lroot", "lroot_f", "liuzheng");
	}
	/**
	 * 关闭连接，释放资源
	 * @throws Exception
	 */
	public void closeConnection() throws Exception {
		conn.close();
	}
}

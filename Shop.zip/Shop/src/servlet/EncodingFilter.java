package servlet;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

/**
 * 过滤全局编码方式为UTF-8
 * @author liuzheng
 */
@WebFilter("/EncodingFilter")
public class EncodingFilter implements Filter {

   
    public EncodingFilter() {}
	public void destroy() {}

	/**
	 * 过滤器设置编码方式
	 * @author liuzheng 2018/12/18
	 * 
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		chain.doFilter(request, response);
	}
	public void init(FilterConfig fConfig) throws ServletException {}
}

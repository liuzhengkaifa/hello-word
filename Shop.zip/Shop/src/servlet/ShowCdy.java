package servlet;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import dao.CommodityDao;
import vo.CommodityVo;

/**
 * Servlet implementation class ShowCdy
 */
@WebServlet("/ShowCdy")
public class ShowCdy extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CommodityDao cdao = new CommodityDao();
		HashMap allcdy = new HashMap();
		try {
			allcdy = cdao.getAllCommodity();
			request.setAttribute("allCdy",allcdy);
			request.getSession().setAttribute("allCdy", allcdy);
			response.sendRedirect("/Shop/ListCdy.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			}
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		}

}

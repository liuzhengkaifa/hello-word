package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.AddressDao;

/**
 * @author liuzheng 2018/12/18
 * 删除指定地址信息
 *
 */
@WebServlet("/DeleteAddress")
public class DeleteAddress extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		AddressDao adao = new AddressDao();
		String ars_no = request.getParameter("ars_no");
		Integer no = Integer.valueOf(ars_no); 
		System.out.println("这是DelteAddress的servlet的Doget方法！");
		System.out.println("获取到的地址编号:"+ars_no);
		try {
			adao.deleteAddress(no);
			response.sendRedirect("/Shop/ShowAddress");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}

package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.AddressDao;

/**
 * 用于新增以及修改地址信息
 * @author liuzheng 2018/12/18
 *
 */
@WebServlet("/EditAddress")
public class EditAddress extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		doGet(request, response);
//		request.setCharacterEncoding("gbk");
		AddressDao adao = new AddressDao();
		String ars_name=request.getParameter("arsName");
		String ars_phone=request.getParameter("arsPhone");
		Integer ars_code=Integer.valueOf(request.getParameter("arsPostCode"));
		String ars_address=request.getParameter("arsAddress");
		Integer user_id=Integer.valueOf(request.getParameter("arsUserId"));
		Integer flag=Integer.valueOf(request.getParameter("flag"));
		Integer ars_no=Integer.valueOf(request.getParameter("arsNo"));
		System.out.println(ars_name+ars_phone+ars_code+ars_address+user_id+ars_no);
		try {
			System.out.println("EditAddress的servlet处理界面");
			adao.addAddress(ars_name, ars_phone,ars_code,ars_address, user_id,flag,ars_no);
			response.sendRedirect("/Shop/ShowAddress");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

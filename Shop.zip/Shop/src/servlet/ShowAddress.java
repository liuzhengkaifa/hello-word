package servlet;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.AddressDao;

/**
 * Servlet implementation class ShowAddress
 */
@WebServlet("/ShowAddress")
public class ShowAddress extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		AddressDao adao = new AddressDao();
		HashMap allAdress = null;
		try {
			allAdress = adao.getAllAddress();
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		try {
			allAdress = adao.getAllAddress();
			request.setAttribute("allAdress",allAdress);
			request.getSession().setAttribute("allAdress", allAdress);
			response.sendRedirect("/Shop/ListAddress.jsp");		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}

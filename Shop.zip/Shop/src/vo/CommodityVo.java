package vo;

public class CommodityVo {
	private String cdyName;
	private String cdyColor;
	private String cdySize;
	private double cdyPrice;
	private int cdyNo;
	public int getCdyNo() {
		return cdyNo;
	}
	public void setCdyNo(int cdyNo) {
		this.cdyNo = cdyNo;
	}
	private String stoNo;
	public String getCdyName() {
		return cdyName;
	}
	public void setCdyName(String cdyName) {
		this.cdyName = cdyName;
	}
	public String getCdyColor() {
		return cdyColor;
	}
	public void setCdyColor(String cdyColor) {
		this.cdyColor = cdyColor;
	}
	public String getCdySize() {
		return cdySize;
	}
	public void setCdySize(String cdySize) {
		this.cdySize = cdySize;
	}
	public double getCdyPrice() {
		return cdyPrice;
	}
	public void setCdyPrice(double cdyPrice) {
		this.cdyPrice = cdyPrice;
	}
	public String getStoNo() {
		return stoNo;
	}
	public void setStoNo(String stoNo) {
		this.stoNo = stoNo;
	}
}

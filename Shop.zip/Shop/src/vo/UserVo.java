package vo;

public class UserVo {
	private String nickName;
	private String phone;
	private String password;
	public int getId() {
		return id;
	}
//	public void setId(int id) {
//		this.id = id;
//	}
	private int id;
	public String getNickName() {
		return nickName;
	}
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
